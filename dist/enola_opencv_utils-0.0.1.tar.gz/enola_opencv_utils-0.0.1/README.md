# OPENCV UTILS
It is a collection of class and function to helper with the manage of OpenCV.

## Video and Image
...
